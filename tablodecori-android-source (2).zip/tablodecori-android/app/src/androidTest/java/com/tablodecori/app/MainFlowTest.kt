package com.tablodecori.app

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import org.junit.Rule
import org.junit.Test

class MainFlowTest {
    @get:Rule val rule=createAndroidComposeRule<MainActivity>()
    @Test fun homeAndQuickNavigationAreVisible(){
        rule.waitUntil(5000){runCatching{rule.onAllNodes(androidx.compose.ui.test.hasText("محاسبه سریع")).fetchSemanticsNodes().isNotEmpty()}.getOrDefault(false)}
        rule.onNodeWithText("محاسبه سریع",useUnmergedTree=true).assertIsDisplayed()
    }
}
