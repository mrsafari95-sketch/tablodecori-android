package com.tablodecori.app
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.tablodecori.app.data.WorkshopRepository
class MainViewModelFactory(private val repo: WorkshopRepository):ViewModelProvider.Factory{
    @Suppress("UNCHECKED_CAST") override fun <T:ViewModel> create(modelClass:Class<T>):T=MainViewModel(repo) as T
}
