package com.tablodecori.app.pricing

object OrderMath {
    fun actualProfit(receivedToman: Long, snapshottedProductCostToman: Long, shippingToman: Long): Long =
        receivedToman - snapshottedProductCostToman - shippingToman
}
