package com.tablodecori.app.pricing

import org.junit.Assert.*
import org.junit.Test

class PricingEngineTest {
    private val engine=PricingEngine()
    private val profits=mapOf(1 to 250000L,2 to 350000L,3 to 450000L,4 to 650000L,5 to 800000L,6 to 950000L,7 to 1100000L,8 to 1250000L,9 to 1400000L)
    private fun m(id:String,type:CalculationType,price:Long=0,waste:Int=0,rate:Int=0,cat:MaterialCategory=MaterialCategory.PRODUCTION)=MaterialInput(id,id,cat,type,price,rate,waste,true)

    @Test fun glass20x30(){val r=engine.calculate(listOf(PieceInput(20,30,1)),listOf(m("glass",CalculationType.PER_SQUARE_METER,300000)),setOf("glass"),profits,1);assertEquals(18000,r.costBeforeProfitToman);assertEquals("0.06",r.totalAreaSquareMeters.stripTrailingZeros().toPlainString())}
    @Test fun glassWaste5Percent(){val r=engine.calculate(listOf(PieceInput(20,30,1)),listOf(m("glass",CalculationType.PER_SQUARE_METER,300000,500)),setOf("glass"),profits,1);assertEquals(18900,r.costBeforeProfitToman)}
    @Test fun pvcPerimeter20x30IsOneMeter(){val r=engine.calculate(listOf(PieceInput(20,30,1)),listOf(m("pvc",CalculationType.PER_LINEAR_METER,185000)),setOf("pvc"),profits,1);assertEquals("1",r.totalPerimeterMeters.stripTrailingZeros().toPlainString());assertEquals(185000,r.costBeforeProfitToman)}
    @Test fun fourPieceIrregularSet(){val pieces=listOf(PieceInput(40,60,1),PieceInput(20,30,2),PieceInput(16,21,1));val r=engine.calculate(pieces,listOf(m("glass",CalculationType.PER_SQUARE_METER,300000,500)),setOf("glass"),profits,1);assertEquals(4,r.pieceCount);assertEquals("0.3936",r.totalAreaSquareMeters.toPlainString());assertEquals(123984,r.costBeforeProfitToman);assertEquals(650000,r.profitToman)}
    @Test fun ninePieceSet(){val p=listOf(PieceInput(40,60,1),PieceInput(30,40,4),PieceInput(20,30,4));val r=engine.calculate(p,listOf(m("labor",CalculationType.PER_PIECE,65000)),setOf("labor"),profits,1);assertEquals(9,r.pieceCount);assertEquals(585000,r.costBeforeProfitToman);assertEquals(1400000,r.profitToman)}
    @Test fun glassCanBeDisabled(){val p=listOf(PieceInput(40,60,1));val mats=listOf(m("glass",CalculationType.PER_SQUARE_METER,300000),m("labor",CalculationType.PER_PIECE,65000));val on=engine.calculate(p,mats,setOf("glass","labor"),profits,1);val off=engine.calculate(p,mats,setOf("labor"),profits,1);assertTrue(on.costBeforeProfitToman>off.costBeforeProfitToman);assertFalse(off.lines.any{it.materialId=="glass"})}
    @Test fun backboardCanBeDisabled(){val p=listOf(PieceInput(40,60,1));val mats=listOf(m("back",CalculationType.PER_SQUARE_METER,145000),m("labor",CalculationType.PER_PIECE,65000));val r=engine.calculate(p,mats,setOf("labor"),profits,1);assertFalse(r.lines.any{it.materialId=="back"});assertEquals(65000,r.costBeforeProfitToman)}
    @Test fun inflationAppliedBeforeProfit(){val mats=listOf(m("base",CalculationType.PER_SET,100000),m("inflation",CalculationType.PERCENT_OF_COST,rate=700,cat=MaterialCategory.OVERHEAD));val r=engine.calculate(listOf(PieceInput(20,30,1)),mats,mats.map{it.id}.toSet(),profits,1);assertEquals(107000,r.costBeforeProfitToman);assertEquals(250000,r.profitToman)}
    @Test fun unexpectedCostApplied(){val mats=listOf(m("base",CalculationType.PER_SET,100000),m("unexpected",CalculationType.PERCENT_OF_COST,rate=300,cat=MaterialCategory.OVERHEAD));val r=engine.calculate(listOf(PieceInput(20,30,1)),mats,mats.map{it.id}.toSet(),profits,1);assertEquals(103000,r.costBeforeProfitToman)}
    @Test fun profitRuleThreePieces(){val r=engine.calculate(listOf(PieceInput(20,30,3)),emptyList(),emptySet(),profits,1);assertEquals(450000,r.profitToman)}
    @Test fun profitRuleFourPieces(){val r=engine.calculate(listOf(PieceInput(20,30,4)),emptyList(),emptySet(),profits,1);assertEquals(650000,r.profitToman)}
    @Test fun shippingNeverEntersBasePrice(){val r=engine.calculate(listOf(PieceInput(20,30,1)),listOf(m("labor",CalculationType.PER_PIECE,65000)),setOf("labor"),profits,1);assertEquals(315000,r.finalPriceToman);assertEquals(65000,r.costBeforeProfitToman)}
    @Test fun realOrderProfitIncludesShipping(){assertEquals(235000,OrderMath.actualProfit(500000,200000,65000))}
    @Test fun glassPriceChangeRecalculates(){val p=listOf(PieceInput(40,60,1));val old=engine.calculate(p,listOf(m("glass",CalculationType.PER_SQUARE_METER,300000)),setOf("glass"),profits,1);val newer=engine.calculate(p,listOf(m("glass",CalculationType.PER_SQUARE_METER,350000)),setOf("glass"),profits,1);assertEquals(72000,old.costBeforeProfitToman);assertEquals(84000,newer.costBeforeProfitToman)}
    @Test fun oldOrderSnapshotDoesNotChangeAfterMaterialPriceChange(){val p=listOf(PieceInput(40,60,1));val old=engine.calculate(p,listOf(m("glass",CalculationType.PER_SQUARE_METER,300000)),setOf("glass"),profits,1);val snapshot=old.costBeforeProfitToman;engine.calculate(p,listOf(m("glass",CalculationType.PER_SQUARE_METER,350000)),setOf("glass"),profits,1);assertEquals(72000,snapshot);assertEquals(428000,OrderMath.actualProfit(500000,snapshot,0))}
}
