package com.tablodecori.app.data

import androidx.room.withTransaction
import com.tablodecori.app.data.db.*

object SeedData {
    suspend fun seedIfNeeded(db: AppDatabase) {
        if (db.materialDao().getAll().isNotEmpty()) return
        val now = System.currentTimeMillis()
        val vars = listOf(
            MaterialEntity("frame","فریم PVC","PRODUCTION","PER_LINEAR_METER",185000,wasteBasisPoints=1000,smartKind="GENERIC",createdAt=now,updatedAt=now),
            MaterialEntity("glass","شیشه","PRODUCTION","PER_SQUARE_METER",300000,wasteBasisPoints=500,createdAt=now,updatedAt=now),
            MaterialEntity("back","شاسی ۳ میل","PRODUCTION","PER_SQUARE_METER",145000,wasteBasisPoints=500,createdAt=now,updatedAt=now),
            MaterialEntity("photo","عکس","PRODUCTION","PER_SQUARE_METER",420000,wasteBasisPoints=300,createdAt=now,updatedAt=now),
            MaterialEntity("frameSup","ملزومات قاب","PRODUCTION","PER_PIECE",22000,createdAt=now,updatedAt=now),
            MaterialEntity("labor","دستمزد تولید","PRODUCTION","PER_PIECE",65000,createdAt=now,updatedAt=now),
            MaterialEntity("foam","فوم بسته‌بندی","PACKAGING","SMART_PACKAGING",70000,smartKind="FOAM",createdAt=now,updatedAt=now),
            MaterialEntity("carton","کارتن بسته‌بندی","PACKAGING","SMART_PACKAGING",120000,smartKind="CARTON",createdAt=now,updatedAt=now),
            MaterialEntity("tape","چسب پهن","PACKAGING","SMART_PACKAGING",30000,smartKind="TAPE",createdAt=now,updatedAt=now),
            MaterialEntity("label","لیبل","PACKAGING","PER_SET",10000,createdAt=now,updatedAt=now),
            MaterialEntity("strap","تسمه","PACKAGING","SMART_PACKAGING",60000,smartKind="STRAP",createdAt=now,updatedAt=now),
            MaterialEntity("packWorker","هزینه کارگر بسته‌بندی","PACKAGING","PER_SET",70000,createdAt=now,updatedAt=now),
            MaterialEntity("inflation","تورم / حاشیه تغییر قیمت","OVERHEAD","PERCENT_OF_COST",0,rateBasisPoints=700,createdAt=now,updatedAt=now),
            MaterialEntity("unexpected","هزینه پیش‌بینی‌نشده","OVERHEAD","PERCENT_OF_COST",0,rateBasisPoints=300,createdAt=now,updatedAt=now),
        )
        val products = listOf(
            ProductEntity("p4sample","ست ۴ تکه نمونه",createdAt=now,updatedAt=now),
            ProductEntity("p9sample","ست ۹ تکه نمونه",createdAt=now,updatedAt=now),
            ProductEntity("p3-40","ست ۳ تکه ۴۰×۶۰",createdAt=now,updatedAt=now),
        )
        val pieces = listOf(
            ProductPieceEntity(productId="p4sample",widthCm=40,heightCm=60,quantity=1,sortOrder=0),
            ProductPieceEntity(productId="p4sample",widthCm=20,heightCm=30,quantity=2,sortOrder=1),
            ProductPieceEntity(productId="p4sample",widthCm=16,heightCm=21,quantity=1,sortOrder=2),
            ProductPieceEntity(productId="p9sample",widthCm=40,heightCm=60,quantity=1,sortOrder=0),
            ProductPieceEntity(productId="p9sample",widthCm=30,heightCm=40,quantity=4,sortOrder=1),
            ProductPieceEntity(productId="p9sample",widthCm=20,heightCm=30,quantity=4,sortOrder=2),
            ProductPieceEntity(productId="p3-40",widthCm=40,heightCm=60,quantity=3,sortOrder=0),
        )
        val links = products.flatMap { p -> vars.map { ProductVariableEntity(p.id, it.id, true) } }
        val profits = listOf(250000L,350000L,450000L,650000L,800000L,950000L,1100000L,1250000L,1400000L)
            .mapIndexed { i, v -> ProfitRuleEntity(i+1, fixedToman=v, updatedAt=now) }
        db.withTransaction {
            db.materialDao().upsertAll(vars)
            products.forEach { db.productDao().upsert(it) }
            db.productDao().insertPieces(pieces)
            db.productDao().insertVariables(links)
            db.profitRuleDao().upsertAll(profits)
            db.settingsDao().upsert(AppSettingsEntity(updatedAt=now))
        }
    }
}
