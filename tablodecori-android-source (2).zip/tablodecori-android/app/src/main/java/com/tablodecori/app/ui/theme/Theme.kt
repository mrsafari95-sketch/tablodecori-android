package com.tablodecori.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Green=Color(0xFF174C3E); private val Green2=Color(0xFF236B57); private val Gold=Color(0xFFB8923D)
private val Light=lightColorScheme(primary=Green2,onPrimary=Color.White,secondary=Gold,background=Color(0xFFF4F5F2),surface=Color.White,onSurface=Color(0xFF18231F),surfaceVariant=Color(0xFFE8F2EE))
private val Dark=darkColorScheme(primary=Color(0xFF76B7A1),secondary=Color(0xFFD5B86D),background=Color(0xFF0E1512),surface=Color(0xFF16201C),onSurface=Color(0xFFEAF1ED),surfaceVariant=Color(0xFF22332C))
@Composable fun TablodecoriTheme(darkMode:Boolean?=null,content: @Composable () -> Unit){ MaterialTheme(colorScheme=if(darkMode ?: isSystemInDarkTheme()) Dark else Light,typography=Typography(),content=content) }
