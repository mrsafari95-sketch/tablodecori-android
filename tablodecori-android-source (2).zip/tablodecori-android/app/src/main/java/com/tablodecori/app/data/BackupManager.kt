package com.tablodecori.app.data

import androidx.room.withTransaction
import com.tablodecori.app.data.db.*
import org.json.JSONArray
import org.json.JSONObject

class BackupManager(private val db: AppDatabase) {
    suspend fun exportJson(): String {
        val d = db.backupDao()
        val materials=d.materials(); val products=d.products(); val pieces=d.pieces(); val variables=d.variables()
        val profits=d.profits(); val orders=d.orders(); val costs=d.costs(); val history=d.history(); val settings=d.settings()
        return JSONObject().apply {
            put("format", "tablodecori-backup")
            put("version", 1)
            put("createdAt", System.currentTimeMillis())
            put("materials", JSONArray(materials.map { it.toJson() }))
            put("products", JSONArray(products.map { it.toJson() }))
            put("pieces", JSONArray(pieces.map { it.toJson() }))
            put("productVariables", JSONArray(variables.map { it.toJson() }))
            put("profitRules", JSONArray(profits.map { it.toJson() }))
            put("orders", JSONArray(orders.map { it.toJson() }))
            put("orderCosts", JSONArray(costs.map { it.toJson() }))
            put("priceHistory", JSONArray(history.map { it.toJson() }))
            put("settings", JSONArray(settings.map { it.toJson() }))
        }.toString(2)
    }

    suspend fun restoreJson(raw: String) {
        val root = JSONObject(raw)
        require(root.optString("format") == "tablodecori-backup" && root.optInt("version") == 1) { "فایل پشتیبان معتبر نیست." }
        val materials = root.arr("materials") { MaterialEntity(
            it.s("id"),it.s("name"),it.s("category"),it.s("calculationType"),it.l("priceToman"),it.i("rateBasisPoints"),it.i("wasteBasisPoints"),it.b("enabled"),it.s("smartKind"),it.b("deleted"),it.l("createdAt"),it.l("updatedAt")) }
        val products = root.arr("products") { ProductEntity(it.s("id"),it.s("name"),it.b("active"),it.b("deleted"),it.l("createdAt"),it.l("updatedAt")) }
        val pieces = root.arr("pieces") { ProductPieceEntity(it.l("id"),it.s("productId"),it.i("widthCm"),it.i("heightCm"),it.i("quantity"),it.i("sortOrder")) }
        val links = root.arr("productVariables") { ProductVariableEntity(it.s("productId"),it.s("materialId"),it.b("enabled")) }
        val profits = root.arr("profitRules") { ProfitRuleEntity(it.i("pieceCount"),it.s("ruleType"),it.l("fixedToman"),it.b("enabled"),it.l("updatedAt")) }
        val orders = root.arr("orders") { SentOrderEntity(it.s("id"),it.s("internalNumber"),it.l("dateEpochMillis"),it.s("customerName"),it.s("instagramId"),it.s("phone"),it.s("province"),it.s("city"),it.n("productId"),it.s("productNameSnapshot"),it.s("compositionSnapshot"),it.i("pieceCountSnapshot"),it.l("productCostSnapshotToman"),it.l("shippingCostToman"),it.l("receivedToman"),it.l("actualProfitToman"),it.s("note"),it.l("createdAt")) }
        val costs = root.arr("orderCosts") { OrderCostSnapshotEntity(it.l("id"),it.s("orderId"),it.n("materialId"),it.s("name"),it.s("category"),it.l("amountToman")) }
        val history = root.arr("priceHistory") { PriceChangeHistoryEntity(it.l("id"),it.s("materialId"),it.s("materialName"),it.l("oldPriceToman"),it.l("newPriceToman"),it.i("oldRateBasisPoints"),it.i("newRateBasisPoints"),it.l("changedAt"),it.i("affectedProductCount")) }
        val settings = root.arr("settings") { AppSettingsEntity(it.i("id"),it.l("roundingStepToman"),it.l("shippingDefaultToman"),it.b("darkMode"),it.l("updatedAt")) }
        require(materials.isNotEmpty() && settings.isNotEmpty()) { "فایل پشتیبان ناقص است." }
        val d = db.backupDao()
        db.withTransaction {
            d.clearCosts(); d.clearOrders(); d.clearHistory(); d.clearVariables(); d.clearPieces(); d.clearProducts(); d.clearMaterials(); d.clearProfits(); d.clearSettings()
            d.putMaterials(materials); d.putProducts(products); d.putPieces(pieces); d.putVariables(links); d.putProfits(profits)
            d.putOrders(orders); d.putCosts(costs); d.putHistory(history); d.putSettings(settings)
        }
    }

    private fun MaterialEntity.toJson()=JSONObject().put("id",id).put("name",name).put("category",category).put("calculationType",calculationType).put("priceToman",priceToman).put("rateBasisPoints",rateBasisPoints).put("wasteBasisPoints",wasteBasisPoints).put("enabled",enabled).put("smartKind",smartKind).put("deleted",deleted).put("createdAt",createdAt).put("updatedAt",updatedAt)
    private fun ProductEntity.toJson()=JSONObject().put("id",id).put("name",name).put("active",active).put("deleted",deleted).put("createdAt",createdAt).put("updatedAt",updatedAt)
    private fun ProductPieceEntity.toJson()=JSONObject().put("id",id).put("productId",productId).put("widthCm",widthCm).put("heightCm",heightCm).put("quantity",quantity).put("sortOrder",sortOrder)
    private fun ProductVariableEntity.toJson()=JSONObject().put("productId",productId).put("materialId",materialId).put("enabled",enabled)
    private fun ProfitRuleEntity.toJson()=JSONObject().put("pieceCount",pieceCount).put("ruleType",ruleType).put("fixedToman",fixedToman).put("enabled",enabled).put("updatedAt",updatedAt)
    private fun SentOrderEntity.toJson()=JSONObject().put("id",id).put("internalNumber",internalNumber).put("dateEpochMillis",dateEpochMillis).put("customerName",customerName).put("instagramId",instagramId).put("phone",phone).put("province",province).put("city",city).put("productId",productId?:JSONObject.NULL).put("productNameSnapshot",productNameSnapshot).put("compositionSnapshot",compositionSnapshot).put("pieceCountSnapshot",pieceCountSnapshot).put("productCostSnapshotToman",productCostSnapshotToman).put("shippingCostToman",shippingCostToman).put("receivedToman",receivedToman).put("actualProfitToman",actualProfitToman).put("note",note).put("createdAt",createdAt)
    private fun OrderCostSnapshotEntity.toJson()=JSONObject().put("id",id).put("orderId",orderId).put("materialId",materialId?:JSONObject.NULL).put("name",name).put("category",category).put("amountToman",amountToman)
    private fun PriceChangeHistoryEntity.toJson()=JSONObject().put("id",id).put("materialId",materialId).put("materialName",materialName).put("oldPriceToman",oldPriceToman).put("newPriceToman",newPriceToman).put("oldRateBasisPoints",oldRateBasisPoints).put("newRateBasisPoints",newRateBasisPoints).put("changedAt",changedAt).put("affectedProductCount",affectedProductCount)
    private fun AppSettingsEntity.toJson()=JSONObject().put("id",id).put("roundingStepToman",roundingStepToman).put("shippingDefaultToman",shippingDefaultToman).put("darkMode",darkMode).put("updatedAt",updatedAt)

    private fun JSONObject.s(k:String)=optString(k,"")
    private fun JSONObject.n(k:String):String?=if(isNull(k)) null else optString(k).takeIf { it.isNotBlank() && it != "null" }
    private fun JSONObject.l(k:String)=getLong(k)
    private fun JSONObject.i(k:String)=getInt(k)
    private fun JSONObject.b(k:String)=getBoolean(k)
    private fun <T> JSONObject.arr(k:String, map:(JSONObject)->T):List<T>{ val a=getJSONArray(k); return (0 until a.length()).map { map(a.getJSONObject(it)) } }
}
