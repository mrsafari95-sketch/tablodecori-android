package com.tablodecori.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.tablodecori.app.ui.screens.*
import com.tablodecori.app.ui.theme.TablodecoriTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app=application as TablodecoriApp
        setContent {
            val vm:MainViewModel=viewModel(factory=MainViewModelFactory(app.repository))
            val settings by vm.settings.collectAsState()
            TablodecoriTheme(darkMode=settings?.darkMode){CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl){
                var splash by remember{mutableStateOf(true)};LaunchedEffect(Unit){delay(650);splash=false}
                if(splash) Splash() else MainShell(vm)
            }}
        }
    }
}

@Composable private fun Splash(){Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Image(painterResource(R.drawable.tablodecori_logo),"لوگوی tablodecori",Modifier.size(132.dp).clip(RoundedCornerShape(34.dp)));Spacer(Modifier.height(16.dp));Text("tablodecori",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.ExtraBold);Text("مدیریت قیمت‌گذاری و سفارش کارگاه",color=MaterialTheme.colorScheme.onSurfaceVariant)}}}

private data class NavItem(val route:String,val icon:String,val label:String)
private val bottomItems=listOf(NavItem("home","⌂","خانه"),NavItem("variables","▦","متریال"),NavItem("products","▣","محصولات"),NavItem("quick","⌁","سریع"),NavItem("pricebook","≡","قیمت‌نامه"),NavItem("orders","⇢","سفارش‌ها"))

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun MainShell(vm:MainViewModel){
    val nav=rememberNavController();val entry by nav.currentBackStackEntryAsState();val route=entry?.destination?.route?:"home";val snackbar=remember{SnackbarHostState()}
    LaunchedEffect(Unit){vm.messages.collect{snackbar.showSnackbar(it)}}
    Scaffold(snackbarHost={SnackbarHost(snackbar)},topBar={TopAppBar(title={Row(verticalAlignment=Alignment.CenterVertically){Image(painterResource(R.drawable.tablodecori_logo),null,Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)));Spacer(Modifier.width(9.dp));Column{Text("tablodecori",fontWeight=FontWeight.Bold);Text(titleFor(route),style=MaterialTheme.typography.labelSmall)}}},actions={TextButton(onClick={nav.navigate("settings")}){Text("⚙",style=MaterialTheme.typography.titleLarge)}})},bottomBar={NavigationBar{bottomItems.forEach{i->NavigationBarItem(selected=route==i.route,onClick={nav.navigate(i.route){popUpTo(nav.graph.findStartDestination().id){saveState=true};launchSingleTop=true;restoreState=true}},icon={Text(i.icon,style=MaterialTheme.typography.titleLarge)},label={Text(i.label)})}}}){pad->NavHost(nav,"home",Modifier.padding(pad)){composable("home"){HomeScreen(vm){nav.navigate(it)}};composable("variables"){VariablesScreen(vm)};composable("products"){ProductsScreen(vm)};composable("quick"){QuickScreen(vm)};composable("pricebook"){PricebookScreen(vm)};composable("orders"){OrdersScreen(vm)};composable("reports"){ReportsScreen(vm)};composable("settings"){SettingsScreen(vm)}}}
}
private fun titleFor(r:String)=when(r){"variables"->"متغیرها و متریال‌ها";"products"->"ست‌ها و محصولات";"quick"->"محاسبه سریع";"pricebook"->"قیمت‌نامه";"orders"->"سفارش‌های ارسالی";"reports"->"گزارش‌ها";"settings"->"تنظیمات";else->"مدیریت کارگاه"}
