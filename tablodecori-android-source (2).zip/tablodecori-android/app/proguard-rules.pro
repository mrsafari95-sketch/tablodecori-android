# tablodecori: no custom rules required for the first release.
