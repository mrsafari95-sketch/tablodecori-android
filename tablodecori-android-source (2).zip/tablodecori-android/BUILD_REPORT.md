# گزارش Build / Test — tablodecori

تاریخ تهیه: 2026-09-25

## بررسی‌های انجام‌شده در محیط تحویل

- فایل Prototype V2 بررسی و قواعد Seed، Smart Packaging، Profit Rules، صفحه‌ها و UX آن استخراج شد.
- لوگوی ارسالی در `app/src/main/res/drawable-nodpi/tablodecori_logo.png` قرار گرفت.
- Pricing Engine مستقل با Kotlin/JVM واقعاً با `kotlinc` کامپایل و Harness محاسباتی اجرا شد: **CORE_CHECK_OK**.
- محاسبه ست 4 تکه، مساحت `0.3936 m²`، ست 9 تکه، پرت شیشه و سود واقعی سفارش در Harness تأیید شد.
- تمام فایل‌های XML/Manifest با parser XML بررسی شدند: **XML_OK**.
- تمام Sourceهای Kotlin با parser کامپایلر Kotlin برای خطاهای نحوی اسکن شدند و خطای syntax باقی نماند.

## وضعیت Android Build

Android APK در این محیط تولید نشد. دلیل فنی قابل بازتولید است: محیط اجرا Android SDK/Gradle نصب‌شده ندارد و دسترسی DNS/Network فرایندهای shell برای دانلود Gradle/SDK مسدود است. اجرای واقعی `./gradlew --version` در همین محیط با `java.net.UnknownHostException: services.gradle.org` متوقف شد. بنابراین ادعای Build موفق یا وجود APK در این تحویل نشده است.

پروژه شامل bootstrap wrapper، Gradle files و نسخه‌های Dependency است و در محیط استاندارد Android Studio با اینترنت/SDK باید با دستور زیر Build شود:

```bash
./gradlew test lintDebug assembleDebug
```

پس از Build موفق، APK مورد انتظار:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## مواردی که برای Build نهایی باید اجرا شوند

1. Gradle Sync در Android Studio
2. `./gradlew test`
3. `./gradlew lintDebug`
4. `./gradlew assembleDebug`
5. نصب APK روی حداقل یک گوشی کوچک و یک Emulator/Tablet
6. اجرای `connectedDebugAndroidTest` برای Instrumentation Test
7. بررسی دستی Keyboard overlap، RTL، Scroll، Dark/Light و SAF Backup/Restore

این گزارش عمداً بین «بررسی‌های واقعاً اجراشده» و «بررسی‌های نیازمند Android SDK» تفکیک می‌کند.
