package org.gradle.wrapper;
import java.io.*;import java.net.*;import java.nio.file.*;import java.util.*;import java.util.zip.*;
public class GradleWrapperMain {
  public static void main(String[] args) throws Exception {
    Path root=Paths.get(System.getProperty("user.dir")); Properties p=new Properties();
    try(InputStream in=Files.newInputStream(root.resolve("gradle/wrapper/gradle-wrapper.properties"))){p.load(in);} String url=p.getProperty("distributionUrl").replace("\\:",":");
    String file=url.substring(url.lastIndexOf('/')+1); String dir=file.replace("-bin.zip","").replace(".zip","");
    Path home=Paths.get(System.getProperty("user.home"),".gradle","wrapper","tablodecori",dir); Path gradle=home.resolve(dir).resolve("bin").resolve(isWindows()?"gradle.bat":"gradle");
    if(!Files.exists(gradle)){Files.createDirectories(home);Path zip=home.resolve(file);if(!Files.exists(zip)){System.out.println("Downloading "+url);try(InputStream in=new URL(url).openStream()){Files.copy(in,zip,StandardCopyOption.REPLACE_EXISTING);}}unzip(zip,home);if(!isWindows())gradle.toFile().setExecutable(true);}
    List<String> cmd=new ArrayList<>();cmd.add(gradle.toString());cmd.addAll(Arrays.asList(args));Process proc=new ProcessBuilder(cmd).directory(root.toFile()).inheritIO().start();System.exit(proc.waitFor());
  }
  static boolean isWindows(){return System.getProperty("os.name").toLowerCase().contains("win");}
  static void unzip(Path zip,Path dest)throws Exception{try(ZipInputStream z=new ZipInputStream(Files.newInputStream(zip))){ZipEntry e;while((e=z.getNextEntry())!=null){Path out=dest.resolve(e.getName()).normalize();if(!out.startsWith(dest))throw new IOException("Bad zip entry");if(e.isDirectory())Files.createDirectories(out);else{Files.createDirectories(out.getParent());Files.copy(z,out,StandardCopyOption.REPLACE_EXISTING);}}}}
}
