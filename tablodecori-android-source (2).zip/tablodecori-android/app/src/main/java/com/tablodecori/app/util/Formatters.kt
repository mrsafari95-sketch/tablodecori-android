package com.tablodecori.app.util

import java.text.NumberFormat
import java.util.Locale

private val faNumber = NumberFormat.getNumberInstance(Locale("fa", "IR"))
fun money(value: Long): String = "${faNumber.format(value)} تومان"
fun fa(value: Number): String = faNumber.format(value)
fun percentFromBasisPoints(bp: Int): String = if (bp % 100 == 0) "${fa(bp / 100)}٪" else "${fa(bp / 100.0)}٪"
