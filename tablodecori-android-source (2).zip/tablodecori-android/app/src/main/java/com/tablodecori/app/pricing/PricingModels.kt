package com.tablodecori.app.pricing

enum class MaterialCategory { PRODUCTION, PACKAGING, OVERHEAD }
enum class CalculationType { PER_SQUARE_METER, PER_LINEAR_METER, PER_PIECE, PER_SET, PERCENT_OF_COST, SMART_PACKAGING }
enum class SmartPackagingKind { FOAM, CARTON, TAPE, STRAP, GENERIC }
enum class ProfitRuleType { FIXED, PERCENTAGE, BASED_ON_PIECE_COUNT, BASED_ON_SIZE, CUSTOM_RULE }

data class PieceInput(val widthCm: Int, val heightCm: Int, val quantity: Int)

data class MaterialInput(
    val id: String,
    val name: String,
    val category: MaterialCategory,
    val calculationType: CalculationType,
    val priceToman: Long,
    val rateBasisPoints: Int = 0,
    val wasteBasisPoints: Int = 0,
    val enabled: Boolean = true,
    val smartKind: SmartPackagingKind = SmartPackagingKind.GENERIC,
)

data class CostLine(val materialId: String, val name: String, val category: MaterialCategory, val amountToman: Long)

data class PricingResult(
    val pieceCount: Int,
    val totalAreaSquareMeters: java.math.BigDecimal,
    val totalPerimeterMeters: java.math.BigDecimal,
    val productionCostToman: Long,
    val packagingCostToman: Long,
    val overheadCostToman: Long,
    val costBeforeProfitToman: Long,
    val profitToman: Long,
    val finalPriceToman: Long,
    val lines: List<CostLine>,
)
