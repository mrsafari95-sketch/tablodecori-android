package com.tablodecori.app.util

import java.util.Calendar

object PersianDate {
    private val months = arrayOf("فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند")
    data class Parts(val year:Int,val month:Int,val day:Int) { val label:String get() = "${fa(day)} ${months[month-1]} ${fa(year)}"; val monthKey:String get()="$year-${month.toString().padStart(2,'0')}"; val monthLabel:String get()="${months[month-1]} ${fa(year)}" }
    fun fromEpoch(millis: Long): Parts {
        val c=Calendar.getInstance().apply { timeInMillis=millis }
        val (jy,jm,jd)=gregorianToJalali(c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,c.get(Calendar.DAY_OF_MONTH))
        return Parts(jy,jm,jd)
    }
    fun todayEpoch(): Long = System.currentTimeMillis()

    // Integer conversion based on the standard 2820-year Jalali arithmetic used by common open-source implementations.
    fun gregorianToJalali(gy:Int, gm:Int, gd:Int): IntArray {
        val gdm = intArrayOf(0,31,59,90,120,151,181,212,243,273,304,334)
        var gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + 365*gy + (gy2+3)/4 - (gy2+99)/100 + (gy2+399)/400 + gd + gdm[gm-1]
        var jy = -1595 + 33*(days/12053); days %= 12053
        jy += 4*(days/1461); days %= 1461
        if (days > 365) { jy += (days-1)/365; days=(days-1)%365 }
        val jm:Int; val jd:Int
        if (days < 186) { jm=1+days/31; jd=1+days%31 } else { jm=7+(days-186)/30; jd=1+(days-186)%30 }
        return intArrayOf(jy,jm,jd)
    }
}
